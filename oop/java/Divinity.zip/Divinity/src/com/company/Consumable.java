package com.company;

public interface Consumable {
    void consume(Character target);
}
