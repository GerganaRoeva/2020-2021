package com.company;

public interface Equippable {
}
