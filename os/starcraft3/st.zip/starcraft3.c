#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

// #define THREADS_SCV 5
pthread_mutex_t mutex;

void* workers_job(void* arg)
{
    int* num_mines = (int*)arg;

    int mines[*num_mines];
    for (size_t i = 0; i < *num_mines; i++)
    {
        mines[i] = 500;
    }
        
    int i = 0;

    while(mines[i] != 0)
    {
        // mines[i] = mines[i] - 8;
        sleep(3);
        int res_lock = pthread_mutex_trylock(&mutex);
        if(res_lock == 0)
        {
            mines[i] = mines[i] - 8;
            // sleep(3);
            pthread_mutex_unlock(&mutex);
        }
        else
        {
            sleep(3);
            i++;

        }
        

        i++;
    }
    


    return NULL;    
}

int main(int argc, char const *argv[])
{
    int num_mines = 2;
    if(argc > 1)
    {
        num_mines = atoi(argv[1]);
    }

    // int mines[num_mines];
    // for (size_t i = 0; i < num_mines; i++)
    // {
    //     mines[i] = 2000;
    // }

    pthread_t worker_thr1, worker_thr2, worker_thr3, worker_thr4, worker_thr5;
    int err;

    if((err = pthread_create(&worker_thr1, NULL, &workers_job, &num_mines)))
    {
        printf("error in thr1: %s\n", strerror(err));
        return err;
    }
    if((err = pthread_create(&worker_thr2, NULL, &workers_job, &num_mines)))
    {
        printf("error in thr1: %s\n", strerror(err));
        return err;
    }
    if((err = pthread_create(&worker_thr3, NULL, &workers_job, &num_mines)))
    {
        printf("error in thr1: %s\n", strerror(err));
        return err;
    }
    if((err = pthread_create(&worker_thr4, NULL, &workers_job, &num_mines)))
    {
        printf("error in thr1: %s\n", strerror(err));
        return err;
    }
    if((err = pthread_create(&worker_thr5, NULL, &workers_job, &num_mines)))
    {
        printf("error in thr1: %s\n", strerror(err));
        return err;
    }

    pthread_join(worker_thr1, NULL);
    pthread_join(worker_thr2, NULL);
    pthread_join(worker_thr3, NULL);
    pthread_join(worker_thr4, NULL);
    pthread_join(worker_thr5, NULL);

    return 0;
}
