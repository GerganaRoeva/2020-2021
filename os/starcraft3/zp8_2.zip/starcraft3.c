#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

#define THREADS_SCV 5

pthread_mutex_t mutex_for_mine;
pthread_mutex_t mutex_for_bank;


struct info_SCV_t
{
    int SCV_index;
    int num_mines;
    int mirals_bank;
    int soldiers_count;
};

int are_mines_empty(int mines[], int num_mines)
{
    int count_empty = 0;
    for (size_t i = 0; i < num_mines; i++)
    {
        if(mines[i] == 0) count_empty++;
    }
    if(count_empty == num_mines) return 1;
    return 0;
}


void* workers_job(void* arg)
{
    struct info_SCV_t *info = (struct info_SCV_t*) arg;
    
    int mines[info->num_mines];
    for (size_t i = 0; i < info->num_mines; i++)
    {
        mines[i] = 500;
    }
        
    int i = 1;
    int send;

    // info->soldiers_count == 20 && 

    while(!(are_mines_empty(mines, info->num_mines)))
    {
        if(i > info->num_mines) i = 1;

        sleep(3);
        int res_lock = pthread_mutex_trylock(&mutex_for_mine);
        if(res_lock == 0)
        {
            printf("SCV %d is mining from mineral block %d\n", info->SCV_index, i);
            mines[i-1] = mines[i-1] - 8;
            // sleep(3);
            if(mines[i] < 0)
            send = 8 + mines[i-1];
            else send = 8;
            pthread_mutex_unlock(&mutex_for_mine);

            printf("SCV %d is transporting minerals\n", info->SCV_index);
            sleep(2);

            // pthread_mutex_trylock(&mutex);
            pthread_mutex_lock(&mutex_for_mine);
            info->mirals_bank = info->mirals_bank + send;
            pthread_mutex_unlock(&mutex_for_mine);
            printf("SCV %d delivered minerals to the Command Center\n", info->SCV_index);

        }
        else
        {
            sleep(3);
            i++;
        }

    }
    


    return NULL;    
}

int main(int argc, char const *argv[])
{
    int num_mines = 2;
    if(argc > 1)
    {
        num_mines = atoi(argv[1]);
    }

    struct info_SCV_t info_for_worker;
    info_for_worker.num_mines = num_mines; 
    info_for_worker.mirals_bank = 0;
    info_for_worker.soldiers_count = 0;







    pthread_t worker_thr[THREADS_SCV];
    int err;

    pthread_mutex_init(&mutex_for_bank, NULL);
    pthread_mutex_init(&mutex_for_mine, NULL);

    for(int i = 0; i < THREADS_SCV ; i++)
    {
        info_for_worker.SCV_index = i;
        
        if((err = pthread_create(&worker_thr[i], NULL, &workers_job, &info_for_worker)))
        {
            printf("error in thr: %s\n", strerror(err));
            return 1;
        }
    }

    for(int i = 0; i < THREADS_SCV; i++)
    {
        if((err = pthread_join(worker_thr[i], NULL)))
        {
            printf("error in join: %s\n", strerror(err));
            return 1;
        }
    }

    pthread_mutex_destroy(&mutex_for_mine);
    pthread_mutex_destroy(&mutex_for_bank);

    // printf("klkll");
    
    return 0;
}
