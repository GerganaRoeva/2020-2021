//--------------------------------------------
// NAME: Gergana Roeva
// CLASS: XIb
// NUMBER: 8
// PROBLEM: #4
// FILE NAME: ls.c
// FILE PURPOSE:
// Целта на задачате е да се реализира стандартната UNIX комадна ls с добавена функционалност.
//---------------------------------------------
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>

int A = 0;
int l = 0;
int R = 0;

int only_ls(int argc, char * const argv[])
{
    for(int i = 1; i < argc; i++)
    {
        if(argv[i][0] != '-') return 0;
    }
    return 1;
}

void printlinfo(struct stat data)
{
    if(S_IRUSR  & data.st_mode)      printf("r");
    else                             printf("-");
    if(S_IWUSR  & data.st_mode)      printf("w");
    else                             printf("-");
    if(S_IXUSR  & data.st_mode)      printf("x");
    else                             printf("-");
    if(S_IRGRP  & data.st_mode)      printf("r");
    else                             printf("-");
    if(S_IWGRP  & data.st_mode)      printf("w");
    else                             printf("-");
    if(S_IXGRP  & data.st_mode)      printf("x");
    else                             printf("-");
    if(S_IROTH  & data.st_mode)      printf("r");
    else                             printf("-");
    if(S_IWOTH  & data.st_mode)      printf("w");
    else                             printf("-");
    if(S_IXOTH  & data.st_mode)      printf("x");
    else                             printf("-");

    printf(" %ld",data.st_nlink);

    struct passwd *pw = getpwuid(data.st_uid);
    struct group  *gr = getgrgid(data.st_gid);
    if( pw != 0)                     printf(" %s", pw->pw_name);
    if( gr != 0)                     printf(" %s", gr->gr_name);

    printf(" %ld", data.st_size);
    
    // struct timespec rawtime = data.st_mtim;
    // struct tm *info;

    // info = localtime(&rawtime.tv_sec);
    // strftime(timestr,size, " %B %d %X", info);
    // printf(" %s", timestr);

    struct tm *time;
    time = localtime(&data.st_mtim.tv_sec);
    int size = 100;
    char timestr[size];
    strftime(timestr,size, " %B %d %H:%M", time);
    printf(" %s", timestr);

    time = NULL;
    // timestr[0] = NULL;
}

void ls(char * const name, int argc)
{
    struct stat data;

    if(stat(name, &data) == -1)
    {
        const char* msg1 = "ls: cannot access ";
        const char* msg2 = name;

        char* msg;
        msg = malloc(strlen(msg1)+1+strlen(msg2));
        strcpy(msg, msg1);
        strcat(msg, msg2);

        perror(msg);
    }
    else
    {
        if(S_ISREG(data.st_mode ))         printf("-");
        if(S_ISBLK(data.st_mode ))         printf("b");
        if(S_ISCHR(data.st_mode ))         printf("c");
        if(S_ISSOCK(data.st_mode))         printf("s");
        if(S_ISFIFO(data.st_mode))         printf("p");
        if(S_ISLNK(data.st_mode ))         printf("l");
        if(l && !S_ISDIR(data.st_mode))    printlinfo(data);
        if(!S_ISDIR(data.st_mode))         printf(" %s\n", name);



        if(S_ISDIR(data.st_mode))
        {
            DIR* dir;
            struct dirent *dir_inf; 

            if (argc > 2) printf("%s:\n", name);

            if((dir = opendir(name)) == NULL)
            {
                const char* msg1 = "ls: cannot open directory ";
                const char* msg2 = name;

                char* msg;
                msg = malloc(strlen(msg1)+1+strlen(msg2));
                strcpy(msg, msg1);
                strcat(msg, msg2);

                perror(msg);
            }
            else while((dir_inf = readdir(dir)) != NULL)
            {
                if(A == 0 && dir_inf->d_name[0] == '.')                                continue;
                if(!strcmp(dir_inf->d_name, ".") || !strcmp(dir_inf->d_name, ".."))    continue;

                if(dir_inf->d_type == DT_REG )      printf("-");
                if(dir_inf->d_type == DT_BLK )      printf("b");
                if(dir_inf->d_type == DT_CHR )      printf("c");
                if(dir_inf->d_type == DT_SOCK)      printf("s");
                if(dir_inf->d_type == DT_FIFO)      printf("p");
                if(dir_inf->d_type == DT_LNK )      printf("l");
                if(dir_inf->d_type == DT_DIR )      printf("d");

                stat(dir_inf->d_name, &data);

                if(l) printlinfo(data);

                printf(" %s\n", dir_inf->d_name);
            }
            closedir(dir);
        }
    }
}


int main(int argc, char * const argv[])
{
    int opt;
    
    while((opt = getopt(argc, argv, "AlR")) != -1) 
    { 
        switch(opt)
        { 
            case 'A': A = 1;     break;
            case 'l': l = 1;     break;
            case 'R': R = 1;     break;
        } 
    }

    for(int i = 1; i < argc; i++)
    {
        if (argv[i][0] == '-') continue;  
        if (i != 1) printf("\n");

        ls(argv[i], argc);

        
    }

    if(only_ls(argc, argv)) 
    {
        char buff[100];
        getcwd(buff, 100);
        ls(buff, argc);
    }
    return 0;
}
